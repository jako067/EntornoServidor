<?php $__env->startSection('title','index'); ?>

<?php $__env->startSection('content'); ?>

<?php if($product->available): ?>

Nombre: <?php echo e($product->name); ?> <br>
Marca: <?php echo e($product->brand); ?><br>
Descipción: <?php echo e($product->description); ?><br>
Precio: <?php echo e($product->price); ?><br>
Stock: <?php echo e($product->stock); ?><br>
Imagen: <img src="/storage/<?php echo e($product->img); ?>" alt="imagen usu"><br>

<?php else: ?>

No quedan disponibles

<?php endif; ?>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/products/show.blade.php ENDPATH**/ ?>