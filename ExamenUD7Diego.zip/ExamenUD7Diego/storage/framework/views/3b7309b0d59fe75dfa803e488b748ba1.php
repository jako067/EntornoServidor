<div>
    <!-- Live as if you were to die tomorrow. Learn as if you were to live forever. - Mahatma Gandhi -->
</div>
<?php /**PATH C:\Users\Alex\Desktop\ExamenUD7TuNombre\resources\views/layout/partials/header.blade.php ENDPATH**/ ?>