<div>
    <!-- The best way to take care of the future is to take care of the present moment. - Thich Nhat Hanh -->
</div>
<?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>