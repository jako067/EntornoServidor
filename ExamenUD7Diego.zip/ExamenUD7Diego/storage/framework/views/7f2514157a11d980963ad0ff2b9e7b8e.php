<?php $__env->startSection('title','index'); ?>

<?php $__env->startSection('content'); ?>

<h1>Listado de Productos</h1>

<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <a href="<?php echo e(route('product.show',$product)); ?>"><?php echo e($product->name); ?></a>
    <?php echo e($product->price); ?>

    <br>

    <a href="<?php echo e(route('product.edit',$product)); ?>">Editar</a>

    <form action="<?php echo e(route('product.destroy', $product)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <input type="submit" value="eliminar libro">
    </form>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

No hay productos

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/products/index.blade.php ENDPATH**/ ?>