<div>
    <!-- Live as if you were to die tomorrow. Learn as if you were to live forever. - Mahatma Gandhi -->
</div>
<?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/layout/partials/header.blade.php ENDPATH**/ ?>