<?php $__env->startSection('title','index'); ?>

<?php $__env->startSection('content'); ?>


<form action="<?php echo e(route('product.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="name"> Nombre: </label>
    <input type="text" name="name" id="name" class="name">

    <label for="brand"> Marca: </label>
    <input type="text" name="brand" id="brand" class="brand">

    <label for="description"> Descripción: </label>
    <input type="text" name="description" id="description" class="description">

    <label for="price"> Precio: </label>
    <input type="text" name="price" id="price" class="price">

    <label for="stock"> Stock: </label>
    <input type="text" name="stock" id="stock" class="stock">

    <label for="available"> Available: </label>
    <input type="checkbox" name="available" id="available" class="available">

    <label for="img"> Imagen: </label>
    <input type="file" name="img" id="img" class="img">

    <input type="submit" value="submit">

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/products/create.blade.php ENDPATH**/ ?>