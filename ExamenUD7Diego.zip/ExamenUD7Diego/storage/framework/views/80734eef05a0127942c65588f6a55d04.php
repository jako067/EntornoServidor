<?php $__env->startSection('title','edit'); ?>

<?php $__env->startSection('content'); ?>


<form action="<?php echo e(route('product.update',$product)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <label for="name"> Nombre: </label>
    <input type="text" name="name" id="name" class="name" value="<?php echo e($product->name); ?>">

    <label for="brand"> Marca: </label>
    <input type="text" name="brand" id="brand" class="brand" value="<?php echo e($product->brand); ?>">

    <label for="description"> Descripción: </label>
    <input type="text" name="description" id="description" class="description" value="<?php echo e($product->description); ?>">

    <label for="price"> Precio: </label>
    <input type="text" name="price" id="price" class="price" value="<?php echo e($product->price); ?>">

    <label for="stock"> Stock: </label>
    <input type="text" name="stock" id="stock" class="stock" value="<?php echo e($product->stock); ?>">

    <label for="available"> Available: </label>
    <input type="checkbox" name="available" id="available" class="available" value="<?php echo e($product->available); ?>">

    <label for="img"> Imagen: </label>
    <input type="file" name="img" id="img" class="img" value="<?php echo e($product->img); ?>">

    <input type="submit" value="submit">

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/products/edit.blade.php ENDPATH**/ ?>