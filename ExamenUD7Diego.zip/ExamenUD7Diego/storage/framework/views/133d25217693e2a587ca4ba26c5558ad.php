<div>
    <!-- The best way to take care of the future is to take care of the present moment. - Thich Nhat Hanh -->
</div>
<?php /**PATH C:\Users\Alex\Desktop\ExamenUD7TuNombre\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>