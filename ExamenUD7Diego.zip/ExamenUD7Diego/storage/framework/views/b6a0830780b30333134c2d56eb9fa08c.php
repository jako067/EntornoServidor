<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>EXAMEN</title>
    <style>
        body {
            height: 30em;
        }
        div {
            text-align: center;
            background-color: #FF8000;
            margin: .4em .4em;
            padding: 2em;
            font-size: 2em;
            font-weight: bolder;
        }
    </style>
</head>
<body>
    <div>
        <span>
            Examen UD 7 y 6
        </span>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\ExamenUD7Diego\resources\views/welcome.blade.php ENDPATH**/ ?>