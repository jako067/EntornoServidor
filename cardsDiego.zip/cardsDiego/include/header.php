<header > 
    <ul class="topbar">
        <li><a href="index.php">Presentación</a> </li>
        <li><a href="higherDiego.php">Higer</a> </li>
        <li><a href="blackjackDiego.php">BlackJack</a> </li>
    </ul>    
</header>

