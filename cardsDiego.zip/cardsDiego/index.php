<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link rel="stylesheet" href="/styles/styles.css">
</head>
<body>
    <h1>CardsDiego</h1>
    <?php
    require_once($_SERVER['DOCUMENT_ROOT'].'/include/header.php');
    ?>
    <img src="/imgs/barajaIndex.jpg" alt="imagen principal">
    
</body>
</html>